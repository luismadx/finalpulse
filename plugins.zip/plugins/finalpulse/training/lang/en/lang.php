<?php return [
    'plugin' => [
        'name' => 'Training',
        'description' => 'Finalpulse'
    ]
];