<?php return [
    'plugin' => [
        'name' => 'Plugin name',
        'description' => 'Plugin description.'
    ]
];
