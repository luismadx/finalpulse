<?php

return [
    'mailgun_domain' => 'Mailgun도메인',
    'mailgun_domain_comment' => 'Mailgun도메인명을 설정해주세요.',
    'mailgun_secret' => 'Mailgun API키',
    'mailgun_secret_comment' => 'Mailgun API키를 설정해주세요.',
];
