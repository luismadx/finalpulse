<?php

return [
    'mailgun_domain'             => 'Domena Mailgun',
    'mailgun_domain_comment'     => 'Proszę podać nazwę domeny Mailgun.',
    'mailgun_secret'             => 'Mailgun Secret',
    'mailgun_secret_comment'     => 'Podaj swój klucz API Mailgun.',
];
