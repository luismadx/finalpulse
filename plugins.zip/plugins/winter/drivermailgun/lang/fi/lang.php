<?php

return [
    'mailgun_domain' => 'Mailgun domain',
    'mailgun_domain_comment' => 'Määritä Mailgun domain nimi.',
    'mailgun_secret' => 'Mailgun sala-avain',
    'mailgun_secret_comment' => 'Syötä sinun Mailgun API sala-avain.',
];
