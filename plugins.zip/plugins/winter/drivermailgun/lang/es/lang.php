<?php

return [
    'mailgun_domain' => 'Dominio Mailgun',
    'mailgun_domain_comment' => 'Por favor, especifique el nombre de dominio Mailgun.',
    'mailgun_secret' => 'Mailgun secret',
    'mailgun_secret_comment' => 'Introduzca su key de Mailgun API.',
];
