<?php

return [
    'mailgun_domain' => 'Mailgun-domene',
    'mailgun_domain_comment' => 'Vennligst oppgi Mailgun-domenenavnet.',
    'mailgun_secret' => 'Mailgun Secret',
    'mailgun_secret_comment' => 'Oppgi din Mailgun-API-nøkkel.',
];
