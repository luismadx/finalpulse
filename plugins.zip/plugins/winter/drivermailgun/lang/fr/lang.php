<?php

return [
    'mailgun_domain' => 'Domaine Mailgun',
    'mailgun_domain_comment' => 'Saisir le nom de domaine Mailgun.',
    'mailgun_secret' => 'Clé secrète Mailgun',
    'mailgun_secret_comment' => 'Saisir votre clé API Mailgun.',
];
