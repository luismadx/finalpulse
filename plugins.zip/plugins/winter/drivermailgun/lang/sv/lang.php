<?php

return [
    'mailgun_domain' => 'Mailgun domän',
    'mailgun_domain_comment' => 'Vänligen ange Mailgun domännamnet.',
    'mailgun_secret' => 'Mailgun hemlighet',
    'mailgun_secret_comment' => 'Ange din Mailgun API-nyckel.',
];
