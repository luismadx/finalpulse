<?php

return [
    'mailgun_domain' => 'Mailgun 域名',
    'mailgun_domain_comment' => '請確認 Mailgun 域名.',
    'mailgun_secret' => 'Mailgun Secret',
    'mailgun_secret_comment' => '輸入您的 Mailgun API key.',
];
