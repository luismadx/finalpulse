<?php

return [
    'mailgun_domain' => 'Mailgun domeen',
    'mailgun_domain_comment' => 'Palun sisesta Mailgun domeeni nimi.',
    'mailgun_secret' => 'Mailgun võti',
    'mailgun_secret_comment' => 'Palun sisesta Mailgun API salajane võti.',
];
