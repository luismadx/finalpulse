<?php

return [
    'mailgun_domain' => 'Mailgun domen',
    'mailgun_domain_comment' => 'Specificiraj Mailgun domen.',
    'mailgun_secret' => 'Mailgun tajna',
    'mailgun_secret_comment' => 'Unesi svoj Mailgun API ključ.',
];
