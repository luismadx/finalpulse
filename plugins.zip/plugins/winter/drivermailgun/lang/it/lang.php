<?php

return [
    'mailgun_domain' => 'Dominio Mailgun',
    'mailgun_domain_comment' => 'Inserisci il nome dominio Mailgun.',
    'mailgun_secret' => 'Chiave Mailgun',
    'mailgun_secret_comment' => 'Inserisci la tua chiave per l\'utilizzo delle API Mailgun.',
];
