<?php

return [
    'mailgun_domain' => 'Mailgun domæne',
    'mailgun_domain_comment' => 'Angiv venligst Mailgun domænenavnet.',
    'mailgun_secret' => 'Mailgun hemmelighed',
    'mailgun_secret_comment' => 'Angiv din Mailgun API key.',
];
