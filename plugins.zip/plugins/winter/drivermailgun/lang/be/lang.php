<?php

return [
    'mailgun_domain' => "Дамен Mailgun",
    'mailgun_domain_comment' => "Калі ласка, укажыце імя дамена Mailgun",
    'mailgun_secret' => "Сакрэт Mailgun",
    'mailgun_secret_comment' => "Увядзіце ключ Mailgun API",
];
