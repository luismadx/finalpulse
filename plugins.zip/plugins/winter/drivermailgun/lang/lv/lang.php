<?php

return [
    'mailgun_domain' => 'Mailgun domēns',
    'mailgun_domain_comment' => 'Lūdzu, norādiet Mailgun domēna vārdu.',
    'mailgun_secret' => 'Mailgun piekļuves atslēga',
    'mailgun_secret_comment' => 'Ievadiet savu Mailgun API atslēgu.',
];
