<?php

return [
    'mailgun_domain' => 'Ranah Mailgun',
    'mailgun_domain_comment' => 'Silakan tentukan nama ranah Mailgun.',
    'mailgun_secret' => 'Mailgun Secret',
    'mailgun_secret_comment' => 'Masukan kunci API Mailgun.',
];
