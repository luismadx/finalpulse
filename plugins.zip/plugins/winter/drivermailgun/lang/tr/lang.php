<?php

return [
    'mailgun_domain' => 'Mailgun Domain',
    'mailgun_domain_comment' => 'Mailgun domain belirtin.',
    'mailgun_secret' => 'Mailgun Gizli Anahtarı',
    'mailgun_secret_comment' => 'Mailgun API anahtarını girin.',
];
