<?php

return [
    'mailgun_domain' => 'Mailgun tartomány',
    'mailgun_domain_comment' => 'Adja meg a Mailgun tartománynevét.',
    'mailgun_secret' => 'Titkos jelszó',
    'mailgun_secret_comment' => 'Adja meg a Mailgun API kulcsát.',
];
