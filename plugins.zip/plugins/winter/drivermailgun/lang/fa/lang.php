<?php

return [
    'mailgun_domain' => 'دامنه ی Mailgun',
    'mailgun_domain_comment' => 'لطفا نام دامنه ی Mailgun را وارد نمایید.',
    'mailgun_secret' => 'امنیت Mailgun',
    'mailgun_secret_comment' => 'کلید API ی مربوط به Mailgun را وارد نمایید.',
];
