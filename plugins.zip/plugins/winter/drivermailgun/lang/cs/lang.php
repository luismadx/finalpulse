<?php

return [
    'mailgun_domain' => 'Mailgun doména (domain)',
    'mailgun_domain_comment' => 'Zadejte doménové jméno (domain name) pro Mailgun.',
    'mailgun_secret' => 'Mailgun tajný klíč (secret)',
    'mailgun_secret_comment' => 'Zadejte váš Mailgun API klíč.',
];
