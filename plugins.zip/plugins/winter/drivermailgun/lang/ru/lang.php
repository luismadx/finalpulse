<?php

return [
    'mailgun_domain'             => 'Домен Mailgun',
    'mailgun_domain_comment'     => 'Пожалуйста, укажите домен Mailgun.',
    'mailgun_secret'             => 'Секретный API-ключ',
    'mailgun_secret_comment'     => 'Введите ваш Mailgun API-ключ.',
];
