<?php

return [
    'mailgun_domain' => 'Mailgunドメイン',
    'mailgun_domain_comment' => 'Mailgunドメイン名を指定してください。',
    'mailgun_secret' => 'Mailgun APIキー',
];
