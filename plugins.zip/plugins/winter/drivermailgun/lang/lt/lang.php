<?php

return [
    'mailgun_domain' => 'Mailgun domenas',
    'mailgun_domain_comment' => 'Nurodykite Mailgun domeno vardą.',
    'mailgun_secret' => 'Mailgun slapukas',
    'mailgun_secret_comment' => 'Įveskite savo Mailgun API raktą.',
];
