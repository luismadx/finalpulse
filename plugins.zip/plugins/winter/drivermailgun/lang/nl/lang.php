<?php

return [
    'mailgun_domain' => 'Mailgun domein',
    'mailgun_domain_comment' => 'Geef hier het Mailgun domeinnaam op.',
    'mailgun_secret' => 'Mailgun secret',
    'mailgun_secret_comment' => 'Geef hier de Mailgun API key op.',
];
