<?php

return [
    'mailgun_domain' => 'Domínio do Mailgun',
    'mailgun_domain_comment' => 'Por favor, forneça o domínio do Mailgun.',
    'mailgun_secret' => 'Mailgun Secret',
    'mailgun_secret_comment' => 'Forneça sua chave de API do Mailgun.',
];
