<?php

return [
    'mailgun_domain'             => 'Mailgun domena',
    'mailgun_domain_comment'     => 'Določite domensko ime za Mailgun (Mailgun domain name).',
    'mailgun_secret'             => 'Mailgun geslo',
    'mailgun_secret_comment'     => 'Vnesite API ključ za Mailgun (Mailgun API key).',
];
