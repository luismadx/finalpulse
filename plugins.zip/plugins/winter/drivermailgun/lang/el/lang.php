<?php

return [
    'mailgun_domain' => 'Mailgun Domain',
    'mailgun_domain_comment' => 'Παρακαλούμε καθορίστε το Domain Name του Mailgun.',
    'mailgun_secret' => 'Mailgun Secret',
    'mailgun_secret_comment' => 'Συμπληρώστε το API κλειδί του Mailgun.',
];
