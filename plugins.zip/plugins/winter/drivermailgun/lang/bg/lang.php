<?php

return [
    'mailgun_domain' => 'Mailgun домейн',
    'mailgun_domain_comment' => 'Моля, посочете домейна за Mailgun.',
    'mailgun_secret' => 'Mailgun тайна',
    'mailgun_secret_comment' => 'Въведете своя Mailgun API ключ.',
];
