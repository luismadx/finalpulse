<?php

return [
    'mailgun_domain' => 'Mailgun домен',
    'mailgun_domain_comment' => 'Будь ласка, вкажіть Mailgun домен.',
    'mailgun_secret' => 'Секретний API-ключ',
    'mailgun_secret_comment' => 'Введіть ваш Mailgun API-ключ.',
];
