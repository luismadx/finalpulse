<?php

return [
    'mailgun_domain' => 'Tên miền trên Mailgun',
    'mailgun_domain_comment' => 'Điền tên miền trên Mailgun',
    'mailgun_secret' => 'Mã bí mật trên Mailgun(secret key)',
    'mailgun_secret_comment' => 'Điền vào mã Mailgun API của bạn',
];
