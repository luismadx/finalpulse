<?php

return [
    'mailgun_domain' => 'Mailgun doména',
    'mailgun_domain_comment' => 'Prosím zadajte názov Mailgun domény.',
    'mailgun_secret' => 'Mailgun tajný kľúč (secret)',
    'mailgun_secret_comment' => 'Zadajta váš Mailgun API kľúč.',
];
