<?php

return [
    'mailgun_domain' => 'Mailgun-Domain',
    'mailgun_domain_comment' => 'Bitte gib die Mailgun-Domain an.',
    'mailgun_secret' => 'Mailgun-Schlüssel',
    'mailgun_secret_comment' => 'Gib Deinen Mailgun-API-Schlüssel an.',
];
