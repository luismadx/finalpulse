<?php

return [
    'mailgun_domain' => 'โดเมน Mailgun',
    'mailgun_domain_comment' => 'กรุณากำหนดโดเมนเนมของ Mailgun',
    'mailgun_secret' => 'Mailgun secret',
    'mailgun_secret_comment' => 'ใส่ Mailgun API key ของท่าน',
];
