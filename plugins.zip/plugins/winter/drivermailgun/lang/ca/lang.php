<?php

return [
    'mailgun_domain' => 'Domini de Mailgun',
    'mailgun_domain_comment' => 'Si us plau especifica el nom de domini de Mailgun.',
    'mailgun_secret' => 'Secret de Mailgun',
    'mailgun_secret_comment' => 'Introdueix la teva clau API de Mailgun.',
];
