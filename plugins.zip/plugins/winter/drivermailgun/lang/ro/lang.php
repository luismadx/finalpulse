<?php

return [
    'mailgun_domain' => 'Domeniu Mailgun',
    'mailgun_domain_comment' => 'Vă rugăm să specificați numele domeniului Mailgun.',
    'mailgun_secret' => 'Cheie secretă pentru Mailgun ',
    'mailgun_secret_comment' => 'Introduceți cheia API Mailgun.',
];
